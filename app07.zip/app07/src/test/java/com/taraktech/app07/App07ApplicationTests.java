package com.taraktech.app07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
