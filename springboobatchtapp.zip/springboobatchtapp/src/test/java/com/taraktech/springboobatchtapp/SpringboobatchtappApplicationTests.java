package com.taraktech.springboobatchtapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringboobatchtappApplicationTests {

	@Test
	void contextLoads() {
	}

}
