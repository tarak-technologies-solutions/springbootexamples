package com.taraktech.springbootapp12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp12Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootapp12Application.class, args);
	}

}
