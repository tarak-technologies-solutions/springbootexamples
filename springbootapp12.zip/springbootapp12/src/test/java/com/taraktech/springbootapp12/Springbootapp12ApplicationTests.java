package com.taraktech.springbootapp12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
