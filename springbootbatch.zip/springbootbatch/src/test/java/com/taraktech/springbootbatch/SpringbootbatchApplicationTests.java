package com.taraktech.springbootbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootbatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
