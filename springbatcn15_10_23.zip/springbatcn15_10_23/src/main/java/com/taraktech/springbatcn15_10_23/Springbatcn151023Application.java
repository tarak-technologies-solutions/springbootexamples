package com.taraktech.springbatcn15_10_23;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbatcn151023Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbatcn151023Application.class, args);
	}

}
