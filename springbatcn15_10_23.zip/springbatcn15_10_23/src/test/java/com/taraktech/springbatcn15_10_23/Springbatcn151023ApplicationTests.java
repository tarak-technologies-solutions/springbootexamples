package com.taraktech.springbatcn15_10_23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbatcn151023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
