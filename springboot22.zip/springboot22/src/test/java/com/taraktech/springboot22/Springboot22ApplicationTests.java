package com.taraktech.springboot22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
