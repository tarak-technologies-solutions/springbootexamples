package com.taraktech.SpringBootApp10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApp10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
