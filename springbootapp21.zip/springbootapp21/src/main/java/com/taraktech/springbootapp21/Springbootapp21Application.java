package com.taraktech.springbootapp21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootapp21Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootapp21Application.class, args);
	}

}
