package com.taraktech.app08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
