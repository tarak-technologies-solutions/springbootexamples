package com.taraktech.SpringBootApp09;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApp09ApplicationTests {

	@Test
	void contextLoads() {
	}

}
