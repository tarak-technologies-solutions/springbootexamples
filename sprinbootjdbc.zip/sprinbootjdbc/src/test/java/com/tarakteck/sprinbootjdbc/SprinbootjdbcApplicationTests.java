package com.tarakteck.sprinbootjdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinbootjdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
