package com.tarakteck.sprinbootjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinbootjdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinbootjdbcApplication.class, args);
	}

}
