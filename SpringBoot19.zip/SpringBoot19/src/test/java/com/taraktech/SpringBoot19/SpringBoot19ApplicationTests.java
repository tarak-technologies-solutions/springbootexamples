package com.taraktech.SpringBoot19;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot19ApplicationTests {

	@Test
	void contextLoads() {
	}

}
