package com.taraktech.springbootapp20;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootapp20ApplicationTests {

	@Test
	void contextLoads() {
	}

}
