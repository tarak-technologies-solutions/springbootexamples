package com.taraktech.springbootbatchapp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootbatchapp2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootbatchapp2Application.class, args);
	}

}
