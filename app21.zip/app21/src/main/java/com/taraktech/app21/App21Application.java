package com.taraktech.app21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App21Application {

	public static void main(String[] args) {
		SpringApplication.run(App21Application.class, args);
	}

}
