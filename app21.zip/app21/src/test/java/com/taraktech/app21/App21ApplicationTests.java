package com.taraktech.app21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
