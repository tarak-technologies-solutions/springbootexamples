package com.taraktech.springboot14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
